"""Multi-channel Twitch capture and bounded candidate extraction."""
from __future__ import annotations

from collections import deque
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import urlparse
from threading import Event, Lock, Thread
from time import monotonic, time
import csv
import os
import re
import shutil
import socket
import ssl
import subprocess
import tempfile

from .common import FFMPEG, load, number, run, save, verify
from .detect import scan

LOGIN = re.compile(r"[a-z0-9_]{2,25}\Z")
UTC_WIDTH = 5
QUALITY = re.compile(r"(?:best|worst|[0-9]{3,4}p(?:[0-9]{2})?)(?:,(?:best|worst|[0-9]{3,4}p(?:[0-9]{2})?))*\Z")


def twitch(value):
    value = value.strip()
    if "://" in value:
        url = urlparse(value)
        if url.scheme != "https" or url.netloc.lower() not in {"www.twitch.tv","twitch.tv"}:
            raise ValueError("Expected a Twitch channel URL")
        value = url.path.strip("/")
    if not LOGIN.fullmatch(value.lower()):
        raise ValueError(f"Invalid Twitch channel: {value}")
    return value.lower()


def credentials():
    username = os.getenv("TWITCH_CHAT_LOGIN", "").lower()
    token = os.getenv("TWITCH_CHAT_TOKEN", "").removeprefix("oauth:")
    if not LOGIN.fullmatch(username) or not re.fullmatch(r"[A-Za-z0-9_-]{10,200}", token):
        raise ValueError("Set TWITCH_CHAT_LOGIN and TWITCH_CHAT_TOKEN (Twitch user token with chat:read)")
    return username, token


def parse_chat(line):
    if not line.startswith("@"):
        return None
    tags, _, line = line.partition(" ")
    match = re.search(r" PRIVMSG #([a-z0-9_]+) :(.*)\Z", line)
    if not match:
        return None
    metadata = dict(tag.split("=", 1) for tag in tags[1:].split(";") if "=" in tag)
    author = metadata.get("user-id")
    stamp = metadata.get("tmi-sent-ts", "")
    if not author or not stamp.isdigit():
        return None
    channel, message = match.groups()
    return channel, int(stamp)/1000, author, message


class Chat:
    def __init__(self, channels, stop):
        self.stop = stop
        self.channels = channels
        self.lock = Lock()
        self.events = {c: deque(maxlen=120000) for c in channels}
        self.username, self.token = credentials()
        self.status = "connecting"
        self.thread = Thread(target=self.listen, daemon=True)

    def listen(self):
        retry = 1
        while not self.stop.is_set():
            try:
                with socket.create_connection(("irc.chat.twitch.tv", 6697), timeout=8) as raw:
                    with ssl.create_default_context().wrap_socket(raw, server_hostname="irc.chat.twitch.tv") as conn:
                        conn.settimeout(2)
                        self.session(conn)
                retry = 1
            except (OSError, ValueError):
                self.status = "reconnecting"
                self.stop.wait(retry)
                retry = min(30,retry*2)
        if self.status != "authentication failed":
            self.status = "stopped"

    def session(self, conn):
        conn.sendall((f"CAP REQ :twitch.tv/tags twitch.tv/commands\r\n"
                      f"PASS oauth:{self.token}\r\nNICK {self.username}\r\n").encode())
        conn.sendall(("JOIN "+",".join("#"+channel for channel in self.channels)+"\r\n").encode())
        buffer = b""
        last_read = monotonic()
        while not self.stop.is_set():
            try:
                block = conn.recv(65536)
            except TimeoutError:
                if monotonic()-last_read > 240:
                    raise ValueError("chat timed out")
                continue
            if not block:
                raise ValueError("chat disconnected")
            last_read = monotonic()
            buffer += block
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n",1)
                text = line.decode(errors="replace").rstrip("\r")
                if text.startswith("PING "):
                    conn.sendall(("PONG "+text[5:]+"\r\n").encode())
                    continue
                if " RECONNECT" in text:
                    raise ValueError("Twitch requested reconnect")
                if " NOTICE * :Login authentication failed" in text or "Improperly formatted auth" in text:
                    self.status = "authentication failed"
                    self.stop.set()
                    return
                if " 001 " in text:
                    self.status = "connected"
                event = parse_chat(text)
                if event and event[0] in self.events:
                    with self.lock:
                        self.events[event[0]].append(event[1:])
            if len(buffer) > 262144:
                raise ValueError("invalid IRC line")

    def read(self, channel, before):
        with self.lock:
            queue = self.events[channel]
            while queue and queue[0][0] < before:
                queue.popleft()
            return list(queue)


def terminate(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=8)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()


def segments(directory):
    index = directory/"segments.csv"
    if not index.exists():
        return []
    with index.open(encoding="utf-8", newline="") as fp:
        rows = []
        for row in csv.reader(fp):
            if len(row)!=3 or not re.fullmatch(r"part-\d+\.ts", row[0]):
                continue
            try:
                start, end = map(float,row[1:])
            except ValueError:
                continue
            path = directory/row[0]
            if path.is_file() and 0 <= start < end:
                rows.append((path,start,end))
        return rows


def extract(rows, start, end, output):
    selected = [(p,s,e) for p,s,e in rows if s < end and e > start]
    if not selected or selected[0][1] > start + 0.04 or selected[-1][2] < end - 0.04:
        raise ValueError("Candidate crosses unavailable recording")
    if any(abs(b[1]-a[2]) > .12 or int(a[0].stem.split("-")[-1])+1 != int(b[0].stem.split("-")[-1])
           for a,b in zip(selected, selected[1:])):
        raise ValueError("Candidate crosses a recording gap")
    with tempfile.TemporaryDirectory(prefix="lelips-candidate-", dir=output.parent) as temp:
        folder = Path(temp)
        spec = folder/"join.txt"
        lines = []
        for i,(path,s,e) in enumerate(selected):
            name = f"part{i}.ts"
            (folder/name).symlink_to(path)
            lines.extend([f"file {name}",f"duration {e-s:.6f}"])
        spec.write_text("\n".join(lines)+"\n",encoding="utf-8")
        rendered = folder/"candidate.mp4"
        length = end-start
        run(FFMPEG+["-f","concat","-safe","1","-i",spec,"-ss",f"{max(0,start-selected[0][1]):.6f}",
                    "-t",f"{length:.6f}","-map","0:v:0","-map","0:a:0",
                    "-vf","fps=30","-af","aresample=async=1000:first_pts=0","-threads","3",
                    "-c:v","libx264","-preset","veryfast","-crf","21","-c:a","aac",rendered],
            timeout=100)
        result = verify(rendered)
        if abs(result["duration"]-length) > .25:
            raise ValueError("Candidate has incomplete media")
        rendered.replace(output)
    return result


def read_markers(folder):
    for path in sorted((folder/"markers").glob("*.json")):
        try:
            yield path.stem, float(load(path)["utc"])
        except (OSError, KeyError, ValueError):
            continue


def candidates(directory, folder, channel, anchor, rows, chat, settings, emitted):
    latest = rows[-1][2]
    baseline_origin = max(0, int(max(anchor, time()-settings["buffer_seconds"]-180)/UTC_WIDTH)*UTC_WIDTH)
    completed_until = int(time()/UTC_WIDTH)*UTC_WIDTH
    events = [(t-baseline_origin, author, text) for t,author,text in chat.read(channel, baseline_origin)
              if baseline_origin <= t < completed_until]
    detected = scan(events,count=24,lag=settings["reaction_seconds"])
    queue = [(f"chat-{int(round((baseline_origin+x['at'])/5)*5)}",
              baseline_origin+x["at"]-anchor, x["score"], "chat") for x in detected]
    queue.extend((f"marker-{key}", mark-anchor, 0, "manual") for key,mark in read_markers(folder))
    for key, at, score, kind in queue:
        if len(emitted) >= settings["max_candidates"]:
            break
        start, end = max(rows[0][1], at-20), at+10
        if key in emitted or any(abs(at-t)<28 for t in emitted.values()):
            continue
        if at < rows[0][1]+2 or end > latest:
            continue
        emitted[key] = at
        output = folder/"candidates"/(directory.name+"-"+key+".mp4")
        try:
            result = extract(rows, start,end,output)
            save(output.with_suffix(".json"), {**result,"channel":channel,
                 "source_url": "https://www.twitch.tv/"+channel,"trigger":kind,"score":score,
                 "estimated_event_in_clip":at-start,"utc_start_estimate":anchor+start,
                 "editorial_review":"required"})
        except (ValueError, OSError, subprocess.TimeoutExpired) as error:
            save(output.with_suffix(".error.json"), {"error":str(error),"trigger":kind})
    return latest


def worker(channel, folder, settings, stop, chat):
    folder.mkdir(parents=True,exist_ok=False)
    (folder/"candidates").mkdir()
    captures = folder/"captures"
    captures.mkdir()
    attempt = 0
    retry = 4
    total_candidates = 0
    while not stop.is_set():
        attempt += 1
        directory = captures/f"run-{attempt:04d}"
        directory.mkdir()
        # Each reconnect has its own segment timeline. Never join across attempts.
        capture = mux = None
        emitted = {}
        wall_start = time()
        with (directory/"streamlink.log").open("wb") as caplog, (directory/"ffmpeg.log").open("wb") as muxlog:
            try:
                capture = subprocess.Popen(["streamlink","--stdout","--stream-timeout","25",
                                            "https://www.twitch.tv/"+channel,settings["quality"]],
                                           stdout=subprocess.PIPE, stderr=caplog, stdin=subprocess.DEVNULL)
                mux = subprocess.Popen(FFMPEG+["-i","pipe:0","-map","0:v:0","-map","0:a:0","-c","copy",
                           "-f","segment","-segment_time","4","-segment_list","segments.csv",
                           "-segment_list_type","csv","part-%08d.ts"], cwd=directory,stdin=capture.stdout,
                           stdout=subprocess.DEVNULL,stderr=muxlog)
                capture.stdout.close()
                anchor = None
                log = folder/"status.json"
                while not stop.is_set() and mux.poll() is None:
                    rows = segments(directory)
                    if rows:
                        if anchor is None:
                            anchor = time()-rows[-1][2]-settings["playback_delay_seconds"]
                            retry = 4
                        candidate_settings = {**settings,"max_candidates":settings["max_candidates"]-total_candidates}
                        latest = candidates(directory,folder,channel,anchor,rows,chat,candidate_settings,emitted)
                        for path,_,end in rows:
                            if end < latest-settings["buffer_seconds"]:
                                path.unlink(missing_ok=True)
                    if shutil.disk_usage(folder).free < 300 * 1024**2:
                        save(log, {"state":"disk limit","chat":chat.status})
                        stop.set()
                        break
                    if anchor is None and time()-wall_start > 75:
                        break
                    save(log, {"state":"recording" if anchor else "waiting for stream","attempt":attempt,
                               "chat":chat.status,"candidates":len(emitted)+total_candidates})
                    stop.wait(1)
            finally:
                terminate(capture)
                terminate(mux)
                for path in directory.glob("part-*.ts"):
                    path.unlink(missing_ok=True)
        total_candidates += len(emitted)
        if stop.is_set():
            break
        save(folder/"status.json",{"state":"retrying offline or disconnected stream","chat":chat.status,
                                  "candidates":total_candidates,"attempt":attempt,"retry_seconds":retry})
        stop.wait(retry)
        retry = min(retry*2,60)
    save(folder/"status.json",{"state":"finished","chat":chat.status,"candidates":total_candidates})
    return {"channel":channel,"attempts":attempt,"candidate_jobs":total_candidates,
            "saved_candidates":len(list((folder/"candidates").glob("*.mp4")))}


class ManualChat:
    status = "manual markers only"

    def read(self, channel, before):
        return []


def watch(config, output, minutes, *, manual=False):
    data = load(config)
    channels = list(dict.fromkeys(twitch(s) for s in data["channels"]))
    limit = int(number(data.get("max_channels",3),1,5,"max channels"))
    if not channels or len(channels) > limit:
        raise ValueError(f"Configure 1–{limit} distinct channels")
    quality = data.get("quality","720p,best")
    if not QUALITY.fullmatch(quality):
        raise ValueError("Invalid stream quality list")
    settings = {"quality":quality,
                "max_candidates":int(number(data.get("max_candidates",6),1,30,"max candidates per channel")),
                "buffer_seconds":number(data.get("buffer_seconds",180),65,600,"rolling buffer"),
                "playback_delay_seconds":number(data.get("playback_delay_seconds",8),0,45,"capture delay estimate"),
                "reaction_seconds":number(data.get("reaction_seconds",4),0,20,"chat reaction lag")}
    for dep in ("streamlink","ffmpeg","ffprobe"):
        if not shutil.which(dep):
            raise ValueError("Missing "+dep)
    minutes = number(minutes,0.1,720,"watch minutes")
    stop = Event()
    chat = ManualChat() if manual else Chat(channels,stop)
    output = Path(output).resolve()
    output.mkdir(parents=True,exist_ok=False)
    if not manual:
        chat.thread.start()
    with ThreadPoolExecutor(max_workers=len(channels)) as pool:
        futures = [pool.submit(worker,c,output/c,settings,stop,chat) for c in channels]
        deadline = monotonic() + minutes*60
        try:
            while monotonic()<deadline and not stop.wait(0.5):
                if any(f.done() and f.exception() for f in futures):
                    break
        except KeyboardInterrupt:
            pass
        finally:
            stop.set()
        result = [f.result() for f in futures]
    if chat.status == "authentication failed":
        raise ValueError("Twitch rejected the chat login or token")
    return result
