"""Filesystem and subprocess primitives."""
from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ASSETS = Path(os.environ.get("LELIPS_ASSETS", str(ROOT / "assets"))).resolve()
FFMPEG = ["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error"]


def run(args, *, timeout=180, cwd=None, stderr=False):
    args = [str(arg) for arg in args]
    if not shutil.which(args[0]):
        raise ValueError(f"Missing executable: {args[0]}")
    result = subprocess.run(args, cwd=cwd, timeout=timeout, capture_output=True, text=True)
    if result.returncode:
        raise ValueError(f"{args[0]} failed: {result.stderr.strip()[-1600:]}")
    return result.stderr if stderr else result.stdout


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as fp:
        temp = Path(fp.name)
        try:
            json.dump(value, fp, indent=2, ensure_ascii=False, allow_nan=False)
            fp.write("\n")
            fp.close()
            temp.replace(path)
        finally:
            temp.unlink(missing_ok=True)


def sha256(path):
    with Path(path).open("rb") as fp:
        digest = hashlib.sha256()
        for block in iter(lambda: fp.read(1024 * 1024), b""):
            digest.update(block)
        return digest.hexdigest()


def number(value, minimum, maximum, field):
    if type(value) not in (float, int) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise ValueError(f"{field} must be between {minimum} and {maximum}")
    return float(value)


def media(path):
    return json.loads(run(["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", path], timeout=30))


def has_stream(info, kind):
    return any(s["codec_type"] == kind and not s.get("disposition", {}).get("attached_pic")
               for s in info["streams"])


def duration(info):
    value = float(info["format"].get("duration", 0))
    return number(value, 0.001, 1e7, "media duration")


def verify(path, *, size=None, expected=None):
    info = media(path)
    streams = info["streams"]
    if not has_stream(info, "video") or not has_stream(info, "audio"):
        raise ValueError("Expected both video and audio")
    video = next(s for s in streams if s["codec_type"] == "video")
    audio = next(s for s in streams if s["codec_type"] == "audio")
    if size and (video["width"], video["height"]) != size:
        raise ValueError(f"Unexpected video size: {video['width']}x{video['height']}")
    length = duration(info)
    if expected is not None and (abs(length - expected) > 0.08 or length > 30.001):
        raise ValueError(f"Expected {expected:.3f}s; got {length:.3f}s")
    if all("duration" in s for s in (video, audio)):
        if abs(float(video["duration"]) - float(audio["duration"])) > 0.085:
            raise ValueError("Audio and video lengths differ by more than 85 ms")
    run(FFMPEG + ["-xerror", "-i", path, "-map", "0:v:0", "-map", "0:a:0", "-f", "null", "-"])
    return {"duration": length, "width": video["width"], "height": video["height"],
            "fps": video["avg_frame_rate"], "full_decode": True}
