"""Intake for existing media, Twitch VODs, and authorized capture tests."""
from pathlib import Path
from time import time
from urllib.parse import urlparse
import importlib.util
import re
import tempfile
import uuid

from .common import FFMPEG, duration, has_stream, load, media, number, run, save, verify
from .detect import scan
from .live import QUALITY, twitch


def capture_test(channel, output, seconds, quality):
    channel = twitch(channel)
    seconds = int(number(seconds,4,120,"capture seconds"))
    if not QUALITY.fullmatch(quality):
        raise ValueError("Invalid quality list")
    output = Path(output).resolve()
    if output.exists() or output.suffix.lower() != ".ts":
        raise ValueError("Use a new output path ending in .ts")
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent,prefix="lelips-capture-") as work:
        temp = Path(work)/"capture.ts"
        url = "https://www.twitch.tv/"+channel
        run(["streamlink","--stream-timeout","20","--stream-segmented-duration",str(seconds),
             "--output",temp,url,quality],timeout=seconds+90)
        report = verify(temp)
        temp.replace(output)
    return {**report,"source_url":url,"output":str(output)}


def fetch_vod(url, output):
    link = urlparse(url)
    if (link.scheme != "https" or link.netloc.lower() not in {"www.twitch.tv","twitch.tv"}
            or not re.fullmatch(r"/videos/[0-9]+/?",link.path)):
        raise ValueError("Use an accessible Twitch URL in the form https://www.twitch.tv/videos/12345")
    path = Path(output).resolve()
    if path.exists() or path.suffix.lower() != ".mp4":
        raise ValueError("Use a new .mp4 destination")
    path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=path.parent,prefix="lelips-vod-") as work:
        tmp = Path(work)/"vod.mp4"
        run(["yt-dlp","--ignore-config","--no-playlist","--no-progress","--socket-timeout","20",
             "--retries","3","--max-filesize","12G","-f","best[height<=720]/best",
             "--remux-video","mp4","-o",tmp,url],timeout=5400)
        if not tmp.is_file():
            raise ValueError("VOD download produced no file, possibly due to the size limit")
        info = media(tmp)
        if not has_stream(info,"video") or not has_stream(info,"audio"):
            raise ValueError("VOD must include video and audio")
        report = {"source_url":url,"duration":duration(info),"output":str(path)}
        tmp.replace(path)
    return report


def review_sheet(source, out, start, end):
    source = Path(source).resolve(strict=True)
    info = media(source)
    length = duration(info)
    start = number(start,0,length-0.1,"start")
    end = number(end if end is not None else min(length,start+60),start+0.1,length,"end")
    out = Path(out).resolve()
    if out.exists() or out.suffix.lower() not in (".jpg",".jpeg",".png"):
        raise ValueError("Use a new image output path")
    out.parent.mkdir(parents=True,exist_ok=True)
    interval = (end-start)/12
    filters = (f"fps=1/{interval:.6f}:round=up,scale=320:180:force_original_aspect_ratio=decrease,"
               "pad=320:180:(ow-iw)/2:(oh-ih)/2,tile=3x4:padding=4:margin=4")
    run(FFMPEG+["-ss",start,"-t",end-start,"-i",source,"-vf",filters,
                "-frames:v","1","-threads","1",out])
    if not out.exists():
        raise ValueError("No contact sheet could be decoded")
    return {"image":str(out),"start":start,"end":end,"interval_seconds":interval,
            "order":"left to right, top to bottom","timing":"approximate; verify boundaries against source"}


def scan_vod(chat_path, video, top, lag):
    chat = load(chat_path)
    rows = chat.get("comments", []) if isinstance(chat,dict) else chat
    if not isinstance(rows,list):
        raise ValueError("Expected TwitchDownloader chat JSON or an array of {at,author,text}")
    parsed = []
    for row in rows:
        try:
            if "content_offset_seconds" in row:
                id_ = row.get("commenter",{}).get("_id","")
                text = row.get("message",{}).get("body","")
                at = float(row["content_offset_seconds"])
            else:
                at = float(row["at"])
                id_ = row["author"]
                text = row["text"]
            parsed.append((at,str(id_),str(text)))
        except (TypeError,KeyError,ValueError,AttributeError):
            continue
    length = duration(media(Path(video).resolve(strict=True)))
    found = scan([(at,author,text) for at,author,text in parsed if at <= length],count=top,lag=lag)
    for item in found:
        item["end"] = min(item["end"],length)
    return {"usable_messages":len(parsed),"candidates":found,"signal":"chat only; review the source"}


def mark(path, channel, at):
    folder = Path(path).resolve()/twitch(channel)
    if not (folder/"status.json").is_file():
        raise ValueError("No watch session status for that channel")
    marker_id = uuid.uuid4().hex[:12]
    stamp = time() if at is None else number(at,time()-600,time()+10,"event Unix timestamp")
    out = folder/"markers"/(marker_id+".json")
    save(out,{"utc":stamp})
    return {"marker":str(out),"utc":stamp}


def speech(file, output, model, language, device, start, end):
    if importlib.util.find_spec("whisper") is None:
        raise ValueError("Install the speech extra before transcription")
    import torch
    import whisper
    file = Path(file).resolve(strict=True)
    output = Path(output)
    if output.exists():
        raise ValueError("Transcript output already exists")
    length = duration(media(file))
    start = number(start,0,length-0.1,"start")
    end = number(end if end is not None else length,start+0.1,length,"end")
    if end-start>180:
        raise ValueError("Choose a candidate range of 180 seconds or less")
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    if device=="cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA was requested but PyTorch reports no usable CUDA device")
    if model=="auto":
        model = "turbo" if device == "cuda" else "small"
    with tempfile.TemporaryDirectory(prefix="lelips-whisper-") as tmp:
        audio = Path(tmp)/"speech.wav"
        run(FFMPEG+["-ss",start,"-i",file,"-t",end-start,"-ac","1","-ar","16000",audio])
        recognizer = whisper.load_model(model,device=device)
        result = recognizer.transcribe(str(audio),language=language,word_timestamps=True,
                                       condition_on_previous_text=False,fp16=device=="cuda",verbose=None)
    words = []
    for segment in result["segments"]:
        for word in segment.get("words", []):
            token = word["word"].strip().replace("{","(").replace("}",")").replace("\\","/")
            s = round(max(0,float(word["start"])),3)
            e = round(min(end-start,float(word["end"])),3)
            if token and e > s:
                words.append({"start":s,"end":e,"text":token,
                              "confidence":round(float(word.get("probability",0)),4)})
    saved = {"source":str(file),"offset":start,"words":sorted(words,key=lambda x:x["start"]),
             "timeline":"starts at zero for the selected range",
             "model":model,"device":device,"language":result.get("language"),
             "word_timing":"Whisper estimate, editor review required"}
    save(output,saved)
    return {"output":str(output),"words":len(words),"model":model,"device":device}
