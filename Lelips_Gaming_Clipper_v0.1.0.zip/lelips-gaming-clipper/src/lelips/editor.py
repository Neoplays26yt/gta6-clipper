"""Frame-addressed vertical editor and export validation."""
from __future__ import annotations

from pathlib import Path
import tempfile
import json
import re

from .audio import catalog
from .common import FFMPEG, duration, has_stream, load, media, number, run, save, verify

FPS = 30
TRANSITIONS = {"cut", "flash", "film-burn"}
AUTO_CUES = {"film-burn": "whoosh", "flash": "flash"}


def plain(text, field, limit=130):
    if not isinstance(text, str) or not text.strip() or len(text) > limit:
        raise ValueError(f"{field} must be 1–{limit} characters")
    if any(ord(c) < 32 or c in "{}\\" for c in text):
        raise ValueError(f"Invalid characters in {field}")
    return text.strip()


def local(root, value):
    if not isinstance(value, str):
        raise ValueError("Expected a local file path")
    return (root / value).resolve(strict=True)


def rect(value, label):
    if not isinstance(value, list) or len(value) != 4:
        raise ValueError(f"{label} must be [x,y,width,height] as fractions")
    x, y, w, h = [number(v, 0, 1, label) for v in value]
    if w < 0.03 or h < 0.03 or x+w > 1.000001 or y+h > 1.000001:
        raise ValueError(f"{label} falls outside the source or is too small")
    return x, y, w, h


def validate_plan(path):
    path = Path(path).resolve()
    root = path.parent
    data = load(path)
    if data.get("version") != 1:
        raise ValueError("Expected edit plan version 1")
    source = local(root, data["source"])
    info = media(source)
    if not has_stream(info, "video") or not has_stream(info, "audio"):
        raise ValueError("Source needs video and audio")
    length = duration(info)
    shots = data["shots"]
    if not isinstance(shots, list) or not 1 <= len(shots) <= 24:
        raise ValueError("Expected 1–24 shots")
    frames = 0
    normalized = []
    last_end = -1
    for shot in shots:
        start = number(shot["start"], 0, length, "shot start")
        end = number(shot["end"], start, length, "shot end")
        frame_count = round((end-start)*FPS)
        if frame_count < 4 or start < last_end - 0.001:
            raise ValueError("Shots must be at least four frames and in chronological source order")
        last_end = start + frame_count/FPS
        layout = shot.get("layout", "context")
        if layout not in ("context", "fill", "stack"):
            raise ValueError(f"Unknown layout: {layout}")
        transition = shot.get("transition", "cut")
        if transition not in TRANSITIONS or (frames == 0 and transition != "cut"):
            raise ValueError("First shot must start on a cut and later transitions must be supported")
        if transition != "cut" and frame_count < 8:
            raise ValueError("Flash and film burn need at least eight frames")
        n = {**shot, "start": start, "frames": frame_count, "at": frames/FPS,
             "layout": layout, "transition": transition,
             "zoom": number(shot.get("zoom", 1), 1, 1.5, "zoom"),
             "focus": number(shot.get("focus", 0.5), 0, 1, "horizontal focus"),
             "pitch": number(shot.get("pitch", 0), -6, 6, "pitch semitones"),
             "push": number(shot.get("push", 0), 0, 0.2, "animated push")}
        if layout == "stack":
            n["face"] = rect(shot["face"], "face crop")
            n["game"] = rect(shot.get("game", [0, 0, 1, 1]), "game crop")
        if shot.get("insert"):
            n["insert_path"] = local(root, shot["insert"])
            if n["insert_path"].suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"}:
                raise ValueError("Cutaway insert must be a still image")
            n["insert_credit"] = plain(shot["insert_credit"], "cutaway credit", 240)
        frames += frame_count
        normalized.append(n)
    if frames > 30*FPS:
        raise ValueError("Total timeline exceeds 30 seconds")
    total = frames/FPS
    words = load(local(root, data["words"]))["words"] if isinstance(data.get("words"), str) else data.get("words", [])
    if not isinstance(words, list) or len(words) > 350:
        raise ValueError("Expected a list of up to 350 caption words")
    previous = 0
    clean_words = []
    for word in words:
        start = number(word["start"], previous, total, "word start")
        end = number(word["end"], start, total, "word end")
        speaker = word.get("speaker", 0)
        if type(speaker) is not int or not 0 <= speaker <= 3 or end <= start:
            raise ValueError("Word duration must be positive and speaker must be 0–3")
        clean_words.append({"start": start, "end": end, "text": plain(word["text"], "caption word", 44),
                            "speaker": speaker, "emphasis": bool(word.get("emphasis", False))})
        previous = start
    cues = data.get("cues", [])
    if not isinstance(cues, list) or len(cues) > 10:
        raise ValueError("Expected up to ten deliberate sound cues")
    active = []
    for cue in cues:
        active.append({**cue, "at": number(cue["at"], 0, total-1/FPS, "cue time"),
                       "gain_db": number(cue.get("gain_db", -17), -40, -6, "cue gain"),
                       "offset": number(cue.get("offset", 0), 0, 10, "cue offset"),
                       "length": number(cue.get("length", 1.5), 0.04, 5, "cue length"),
                       "why": plain(cue["why"], "cue reason")})
    if data.get("transition_sounds", True):
        for shot in normalized:
            if shot["transition"] in AUTO_CUES and not any(abs(x["at"]-shot["at"]) < 0.22 for x in active):
                active.append({"at": shot["at"], "id": AUTO_CUES[shot["transition"]], "gain_db": -19,
                               "length": 0.55, "offset": 0, "why": shot["transition"]+" transition"})
    active.sort(key=lambda x: x["at"])
    if len(active) > 10:
        raise ValueError("Manual and transition sounds together exceed ten cues")
    if any(b["at"] - a["at"] < 0.25 for a, b in zip(active, active[1:])):
        raise ValueError("Space sound cues at least 250 ms apart")
    labels = data.get("labels", [])
    if not isinstance(labels, list) or len(labels) > 4:
        raise ValueError("Expected at most four short graphic labels")
    for label in labels:
        start = number(label["start"], 0, total, "label start")
        number(label["end"], start + 0.10, total, "label end")
        plain(label["text"], "label text", 26)
    music = data.get("music")
    if music:
        music = {"path": local(root, music["path"]), "credit": plain(music["credit"], "music credit", 240),
                 "gain_db": number(music.get("gain_db", -27), -42, -16, "music gain")}
    title = plain(data["title"], "title", 100)
    credit = plain(data["credit"], "source credit", 240)
    return {"source": source, "total": total, "shots": normalized, "words": clean_words,
            "cues": active, "music": music, "labels": labels, "title": title, "credit": credit,
            "pitch_mixed_audio": data.get("pitch_mixed_audio") is True,
            "sound_catalog": local(root, data["sound_catalog"]) if data.get("sound_catalog") else None}


def stamp(seconds):
    ticks = round(seconds * 100)
    h, rem = divmod(ticks, 360000)
    m, rem = divmod(rem, 6000)
    s, cs = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def captions(words, labels, canvas_width, canvas_height):
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {canvas_width}
PlayResY: {canvas_height}
WrapStyle: 0
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Main,DejaVu Sans,{round(canvas_width*0.057)},&H00F3F0E8,&H00FFFFFF,&H00101010,&H80000000,-1,0,0,0,100,100,0,0,1,{canvas_width*0.004:.2f},1,2,{round(canvas_width*.1)},{round(canvas_width*.17)},{round(canvas_height*.22)},1
Style: Label,DejaVu Sans,{round(canvas_width*0.044)},&H00FFFFFF,&H00FFFFFF,&H00211A16,&H00211A16,-1,0,0,0,100,100,0,0,3,9,0,8,50,100,{round(canvas_height*.16)},1
[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    groups = []
    current = []
    for word in words:
        if current and (
            len(current) >= 5 or sum(len(w["text"])+1 for w in current) + len(word["text"]) > 30
            or word["start"] - current[0]["start"] > 1.3
            or word["start"] - current[-1]["end"] > 0.24
            or word["speaker"] != current[-1]["speaker"]
            or current[-1]["text"].endswith((".", "?", "!"))
        ):
            groups.append(current)
            current = []
        current.append(word)
    if current:
        groups.append(current)
    lines = []
    for group_i, group in enumerate(groups):
        next_start = groups[group_i+1][0]["start"] if group_i+1 < len(groups) else float("inf")
        for i, word in enumerate(group):
            end = group[i+1]["start"] if i+1 < len(group) else min(word["end"], next_start)
            if stamp(end) == stamp(word["start"]) or end <= word["start"]:
                continue
            accent = ("&H0069E8FF&", "&H00BBF78C&", "&H00F9B7FF&", "&H00FFE38D&")[word["speaker"]]
            # Raw ASS styling is generated exclusively here; user text cannot inject tags.
            line = " ".join(("{\\c"+accent+"}"
                             + w["text"]+"{\\r}") if (j == i or w["emphasis"]) else w["text"]
                            for j, w in enumerate(group))
            lines.append(f"Dialogue: 0,{stamp(word['start'])},{stamp(end)},Main,,0,0,0,,{line}")
    for label in labels:
        line = "{\\fad(70,120)}" + label["text"]
        lines.append(f"Dialogue: 1,{stamp(label['start'])},{stamp(label['end'])},Label,,0,0,0,,{line}")
    return header + "\n".join(lines) + "\n"


def crop(box):
    x,y,w,h = box
    return f"crop=trunc(iw*{w}/2)*2:trunc(ih*{h}/2)*2:trunc(iw*{x}/2)*2:trunc(ih*{y}/2)*2"


def fill(w,h, focus=0.5):
    return (f"scale={w}:{h}:force_original_aspect_ratio=increase:force_divisible_by=2,"
            f"crop={w}:{h}:(iw-ow)*{focus}:(ih-oh)/2")


def fit(w,h):
    return f"scale={w}:{h}:force_original_aspect_ratio=decrease:force_divisible_by=2"


def picture(graph, label, shot, w, h, index):
    vin = f"[{label}]"
    out = f"[picture{index}]"
    zoom = shot["zoom"]
    focus = shot["focus"]
    if shot.get("insert_path") or shot["layout"] == "fill":
        graph.append(vin + fill(w,h,focus) +
                     f",crop=trunc(iw/{zoom}/2)*2:trunc(ih/{zoom}/2)*2,scale={w}:{h}" + out)
        return out
    a,b = f"[splitA{index}]", f"[splitB{index}]"
    graph.append(vin + "split=2" + a + b)
    if shot["layout"] == "stack":
        upper = round(h*0.30/2)*2
        graph.extend([
            a+crop(shot["face"])+","+fill(w,upper)+f",setsar=1[fa{index}]",
            b+crop(shot["game"])+","+fill(w,h-upper,focus)+f",setsar=1[ga{index}]",
            f"[fa{index}][ga{index}]vstack=2"+out,
        ])
        return out
    graph.extend([
        a+fill(w,h)+f",gblur=sigma={w/44},eq=brightness=-0.19:saturation=0.75[bg{index}]",
        b+fit(w,h)+f",scale=trunc(iw*{zoom}/2)*2:trunc(ih*{zoom}/2)*2[fg{index}]",
        f"[bg{index}][fg{index}]overlay=(W-w)/2:(H-h)/2"+out,
    ])
    return out


def source_graph(plan, w, h):
    args, graph, pairs = [], [], []
    input_count = 0
    for i, shot in enumerate(plan["shots"]):
        seconds = shot["frames"]/FPS
        args += ["-ss", f"{shot['start']:.6f}", "-i", plan["source"]]
        original = input_count
        input_count += 1
        visual = original
        if shot.get("insert_path"):
            args += ["-loop", "1", "-framerate", str(FPS), "-i", shot["insert_path"]]
            visual = input_count
            input_count += 1
        graph.append(f"[{visual}:v]fps={FPS},tpad=stop_mode=clone:stop_duration=0.2,"
                     f"trim=end_frame={shot['frames']},setpts=PTS-STARTPTS[vsrc{i}]")
        pic = picture(graph, f"vsrc{i}", shot,w,h,i)
        if shot["push"]:
            # Supersampling before zoompan limits the one-pixel crop jitter on a slow push.
            z = f"1+{shot['push']}*(1-cos(PI*min(1,on/{shot['frames']-1})))/2"
            graph.append(pic+f"scale={w*2}:{h*2},"
                         f"zoompan=z='{z}':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':"
                         f"d=1:s={w}x{h}:fps={FPS}[pushed{i}]")
            pic = f"[pushed{i}]"
        fx = {"cut": "", "flash": ",fade=t=in:st=0:d=0.14:color=white",
              "film-burn": ",fade=t=in:st=0:d=0.23:color=0xffa052"}[shot["transition"]]
        # Keep matching audio duration by quantizing both tracks to output frames.
        base_audio = f"[{original}:a]aresample=48000,aformat=channel_layouts=stereo,atrim=duration={seconds:.6f}"
        if shot["pitch"]:
            if not plan["pitch_mixed_audio"]:
                raise ValueError("Set pitch_mixed_audio=true after checking that shifting game/music too is acceptable")
            ratio = 2**(shot["pitch"]/12)
            base_audio += f",rubberband=tempo=1:pitch={ratio:.7f}:formant=preserved"
        graph.extend([pic+f"setsar=1,format=yuv420p{fx}[v{i}]",
                      base_audio+f",apad=whole_len={shot['frames']*1600},atrim=end_sample={shot['frames']*1600},"
                      f"asetpts=PTS-STARTPTS,afade=d=0.008,afade=t=out:st={seconds-.008:.6f}:d=0.008[a{i}]"])
        pairs.append(f"[v{i}][a{i}]")
    graph.append("".join(pairs)+f"concat=n={len(pairs)}:v=1:a=1[vmain][amain]")
    return args, graph, input_count


def sound_graph(plan, args, graph, index, private_sfx):
    beds = ["[amain]"]
    used = []
    if plan["cues"]:
        sounds = catalog(plan["sound_catalog"], check=True)
        for i, cue in enumerate(plan["cues"]):
            if cue["id"] not in sounds:
                raise ValueError(f"Unknown SFX ID: {cue['id']}")
            asset = sounds[cue["id"]]
            if asset["license"] == "unverified" and not private_sfx:
                raise ValueError("Unverified sound rights. Use --private-sfx for private review or use a cleared catalog.")
            gain = cue["gain_db"]
            # Snap cue starts to a frame, then convert to an exact 48 kHz sample index.
            start = round(cue["at"] * FPS)
            args += ["-ss", cue["offset"], "-i", asset["path"]]
            graph.append(f"[{index}:a]aresample=48000,aformat=channel_layouts=stereo,"
                         f"atrim=duration={cue['length']},asetpts=PTS-STARTPTS,"
                         f"volume={gain}dB,adelay={start*1600}S:all=1[cue{i}]")
            index += 1
            beds.append(f"[cue{i}]")
            used.append({**cue, "frame": start, "source": asset["source"], "license": asset["license"]})
    if plan["music"]:
        music = plan["music"]
        args += ["-stream_loop", "-1", "-i", music["path"]]
        total = plan["total"]
        graph += ["[amain]asplit=2[dry][duckkey]",
                  f"[{index}:a]aresample=48000,aformat=channel_layouts=stereo,atrim=duration={total:.6f},"
                  f"afade=d=0.15,afade=t=out:st={max(0,total-.35):.6f}:d=0.35[music]",
                  f"[music][duckkey]sidechaincompress=threshold=0.045:ratio=6:attack=18:release=220:"
                  f"makeup=1,volume={music['gain_db']}dB[ducked]"]
        beds = ["[dry]", *beds[1:], "[ducked]"]
    graph.append("".join(beds)+f"amix=inputs={len(beds)}:duration=first:normalize=0,"
                 "alimiter=limit=0.88:level=0:latency=1[aout]")
    return used


def loudness(path):
    log = run(["ffmpeg","-nostdin","-hide_banner","-i",path,"-vn",
               "-af","loudnorm=print_format=json","-f","null","-"],stderr=True)
    match = re.search(r'\{\s*"input_i"[^}]+\}', log)
    if not match:
        return None
    stats = json.loads(match[0])
    return {"integrated_lufs":stats["input_i"],"true_peak_dbtp":stats["input_tp"],
            "range_lu":stats["input_lra"],"measurement_only":True}


def render(plan_path, output, *, preview=False, private_sfx=False, rough=False):
    plan = validate_plan(plan_path)
    width, height = (360,640) if preview else (1080,1920)
    output = Path(output).resolve()
    if output.suffix.lower() != ".mp4":
        raise ValueError("Output must be .mp4")
    report = output.with_suffix(".report.json")
    if output.exists() or report.exists():
        raise ValueError(f"Output or report already exists: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="lelips-render-", dir=output.parent) as folder:
        root = Path(folder)
        plan = {**plan, "cues": [], "music": None, "words": []} if rough else plan
        args, graph, index = source_graph(plan,width,height)
        used = sound_graph(plan,args,graph,index,private_sfx)
        if plan["words"] or plan["labels"]:
            (root/"captions.ass").write_text(captions(plan["words"],plan["labels"],width,height),encoding="utf-8")
            graph.append("[vmain]ass=captions.ass[vout]")
        else:
            graph.append("[vmain]null[vout]")
        (root/"graph.txt").write_text(";\n".join(graph),encoding="utf-8")
        tmp = root/"export.mp4"
        run(FFMPEG+["-filter_complex_threads","2",*args,"-filter_complex_script","graph.txt",
                    "-map","[vout]","-map","[aout]","-t",f"{plan['total']:.6f}",
                    "-c:v","libx264","-preset","fast","-threads","4","-crf","19",
                    "-pix_fmt","yuv420p","-r",str(FPS),"-fps_mode","cfr","-video_track_timescale","30000","-c:a","aac","-b:a","192k","-movflags","+faststart",tmp],
            cwd=root, timeout=420)
        checked = verify(tmp,size=(width,height),expected=plan["total"])
        checked["mix_measurements"] = loudness(tmp)
        tmp.replace(output)
    result = {**checked,"output":str(output),"title":plan["title"],"credit":plan["credit"],
              "music_credit":plan["music"]["credit"] if plan["music"] else None,
              "cutaway_credits":[s["insert_credit"] for s in plan["shots"] if "insert_credit" in s],
              "captions":len(plan["words"]),"used_sfx":used,
              "private_review":private_sfx,"editorial_review":"required"}
    save(report,result)
    return result
