"""Headless CLI for Lelips editors and agents."""
import argparse
import importlib.util
import json
import shutil
import subprocess
import sys

from . import audio, editor, live, source
from .common import run, verify


def doctor():
    tools = {tool:shutil.which(tool) for tool in ("ffmpeg","ffprobe","streamlink","yt-dlp","earshot")}
    filters = run(["ffmpeg","-hide_banner","-filters"]) if tools["ffmpeg"] else ""
    encoders = run(["ffmpeg","-hide_banner","-encoders"]) if tools["ffmpeg"] else ""
    installed = importlib.util.find_spec("whisper") is not None
    cuda = False
    if installed:
        import torch
        cuda = torch.cuda.is_available()
    sfx = audio.catalog(check=True)
    return {"executables":tools,"render_ready":bool(tools["ffprobe"] and "libx264" in encoders
                                                   and "sidechaincompress" in filters and " ass " in filters),
            "pitch_filter":"rubberband" in filters,"openai_whisper":installed,"cuda":cuda,
            "bundled_sound_ids":list(sfx),"twitch_chat_configured":chat_configured(),
            "note":"Presence checks only. Capture and inference require their own tests."}


def chat_configured():
    try:
        live.credentials()
        return True
    except ValueError:
        return False


def command(sub,name,handler,summary,*positions):
    p = sub.add_parser(name,help=summary)
    p.set_defaults(handler=handler)
    for position in positions:
        p.add_argument(position)
    return p


def parser():
    spec = argparse.ArgumentParser(prog="lelips")
    sub = spec.add_subparsers(dest="cmd",required=True)
    command(sub,"doctor",lambda a:doctor(),"check media, capture and speech dependencies")
    p = command(sub,"capture-test",lambda a:source.capture_test(a.channel,a.output,a.seconds,a.quality),
                "record a short Twitch sample","channel","output")
    p.add_argument("--seconds",type=int,default=30)
    p.add_argument("--quality",default="720p,best")
    p = command(sub,"watch",lambda a:live.watch(a.config,a.output,a.minutes,manual=a.manual),
                "monitor multiple Twitch channels during a bounded session","config","output")
    p.add_argument("--minutes",type=float,default=30)
    p.add_argument("--manual",action="store_true",help="accept manual markers without Twitch chat credentials")
    p = command(sub,"mark",lambda a:source.mark(a.session,a.channel,a.at),
                "mark a moment during a capture session","session","channel")
    p.add_argument("--at",type=float)
    command(sub,"fetch-vod",lambda a:source.fetch_vod(a.url,a.output),
            "download an accessible Twitch VOD","url","output")
    p = command(sub,"scan-vod",lambda a:source.scan_vod(a.chat,a.media,a.top,a.lag),
                "rank VOD chat-spike windows","media","chat")
    p.add_argument("--top",type=int,choices=range(1,25),default=8)
    p.add_argument("--lag",type=float,choices=range(0,21),default=4)
    p = command(sub,"sheet",lambda a:source.review_sheet(a.media,a.output,a.start,a.end),
                "make a 12-frame contact sheet","media","output")
    p.add_argument("--start",type=float,default=0)
    p.add_argument("--end",type=float)
    p = command(sub,"transcribe",lambda a:source.speech(a.media,a.output,a.model,a.language,a.device,a.start,a.end),
                "run OpenAI Whisper on a short range","media","output")
    p.add_argument("--model",default="auto",choices=("auto","tiny","base","small","medium","large-v3","turbo"))
    p.add_argument("--language")
    p.add_argument("--device",default="auto",choices=("auto","cuda","cpu"))
    p.add_argument("--start",type=float,default=0)
    p.add_argument("--end",type=float)
    p = command(sub,"render",lambda a:editor.render(a.plan,a.output,preview=a.preview,
                                                    private_sfx=a.private_sfx,rough=a.rough),
                "render a vertical clip and verification report","plan","output")
    p.add_argument("--preview",action="store_true")
    p.add_argument("--private-sfx",action="store_true")
    p.add_argument("--rough",action="store_true",help="omit captions and added SFX/music")
    command(sub,"verify",lambda a:verify(a.media),"probe and fully decode an export","media")
    command(sub,"sfx",lambda a:audio.catalog(check=True),"show and verify the ten bundled sounds")
    p = command(sub,"import-sfx",lambda a:audio.import_pack(a.folder,a.output,a.source,a.license),
                "index locally available sound files","folder","output")
    p.add_argument("--source",required=True)
    p.add_argument("--license",required=True)
    p = command(sub,"openverse",lambda a:audio.openverse(a.query,a.count),
                "find licensed sound metadata","query")
    p.add_argument("--count",type=int,choices=range(1,21),default=8)
    command(sub,"earshot-match",lambda a:audio.earshot_match(a.file,a.description),
            "compare a sound to a cue description with Earshot","file","description")
    command(sub,"real-sfx",lambda a:audio.real_sfx_mix(a.installed_folder,a.video,a.cues,a.output),
            "run an installed Real SFX version using its native cue sheet","installed_folder","video","cues","output")
    return spec


def main():
    args = parser().parse_args()
    try:
        result = args.handler(args)
    except (ValueError,TypeError,AttributeError,KeyError,OSError,RuntimeError,ImportError,subprocess.TimeoutExpired) as error:
        print(f"lelips: {error}",file=sys.stderr)
        return 1
    print(result if isinstance(result,str) else json.dumps(result,indent=2,ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
