"""Rank candidate moments using per-channel chat baselines."""
from collections import defaultdict, deque
from statistics import median
import math
import re

HYPE = re.compile(r"\b(?:lmao+|lol+|kekw|lul|pog+|no way|clip (?:it|that)|wtf|caught in 4k)\b|💀",
                  re.IGNORECASE)
RAID = re.compile(r"\braid(?:ed|ers)?\b", re.IGNORECASE)


def buckets(events, width=5):
    """Accept (timestamp, author ID, message) and retain only counts."""
    counts = defaultdict(dict)
    for moment, author, message in events:
        if not author or not math.isfinite(moment) or moment < 0:
            continue
        bucket = int(moment // width)
        flags = (int(bool(HYPE.search(message))), int(bool(RAID.search(message))))
        old = counts[bucket].get(author, (0, 0))
        counts[bucket][author] = tuple(max(x, y) for x, y in zip(old, flags))
    return {n: (len(users), sum(x[0] for x in users.values()), sum(x[1] for x in users.values()))
            for n, users in counts.items()}


def spike(bucket, history):
    users, hype, raid = bucket
    baseline = max(1, median(x[0] for x in history))
    if users < 4 or raid/users >= 0.3:
        return 0
    if users < baseline * (2.4 if hype >= 2 else 3.2):
        return 0
    return round(users / baseline + min(hype / users, 1), 2)


def scan(events, *, width=5, count=8, lag=4):
    counts = buckets(events, width)
    found = []
    for bucket, tally in sorted(counts.items()):
        history = [counts.get(i, (0,0,0)) for i in range(max(0,bucket-24),bucket)]
        if len(history) < 4:
            continue
        score = spike(tally, history)
        if score:
            peak = max(0, (bucket+0.5)*width - lag)
            found.append({"at": peak, "start": max(0,peak-20), "end": peak+10,
                          "score": score, "unique_chatters": tally[0]})
    selected = []
    for candidate in sorted(found, key=lambda item: item["score"], reverse=True):
        if not any(abs(candidate["at"]-item["at"]) < 29 for item in selected):
            selected.append(candidate)
        if len(selected) >= count:
            break
    return selected
