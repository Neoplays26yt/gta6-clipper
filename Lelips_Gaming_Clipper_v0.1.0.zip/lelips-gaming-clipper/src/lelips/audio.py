"""Sound catalog, discovery and optional companion tool adapters."""
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import json
import shutil

from .common import ASSETS, duration, has_stream, load, media, run, save, sha256

PACK = "https://drive.google.com/drive/folders/1jfMSkmgyRp9J2c0A2ANGmVzYlycCooeR"


def catalog(folder=None, check=False):
    root = Path(folder or ASSETS / "drive-sfx").resolve()
    entries = {}
    for sound in load(root / "manifest.json")["sounds"]:
        sound_path = (root / sound["file"]).resolve()
        if sound_path.parent != root or not sound_path.is_file() or sound["id"] in entries:
            raise ValueError(f"Invalid sound catalog item: {sound['id']}")
        if check and sha256(sound_path) != sound["sha256"]:
            raise ValueError(f"Sound hash mismatch: {sound_path.name}")
        entries[sound["id"]] = {**sound, "path": str(sound_path)}
    return entries


def import_pack(source, destination, origin, license_label, *, replace=False):
    root = Path(source).resolve()
    destination = Path(destination).resolve()
    if not root.is_dir() or root == destination or root in destination.parents:
        raise ValueError("Give an existing sound folder and a separate destination")
    supported = {".wav", ".ogg", ".mp3", ".flac", ".m4a", ".mp4", ".aac"}
    sounds = []
    if destination.exists() and any(destination.iterdir()) and not replace:
        raise ValueError("Catalog destination must be empty")
    for path in sorted(root.iterdir()):
        if not path.is_file() or path.suffix.lower() not in supported:
            continue
        info = media(path)
        if not has_stream(info, "audio") or duration(info) > 60:
            continue
        digest = sha256(path)
        if any(s["id"] == digest[:16] for s in sounds):
            continue
        destination.mkdir(parents=True, exist_ok=True)
        name = digest[:16] + path.suffix.lower()
        shutil.copyfile(path, destination / name)
        sounds.append({"id": digest[:16], "file": name, "name": path.name, "sha256": digest,
                       "source": origin, "license": license_label})
    if not sounds:
        raise ValueError("No usable audio files under 60 seconds were found")
    save(destination / "manifest.json", {"sounds": sounds})
    return sounds


def openverse(query, count):
    url = "https://api.openverse.org/v1/audio/?" + urlencode(
        {"q": query, "category": "sound_effect", "license": "cc0,pdm,by", "page_size": count})
    request = Request(url, headers={"User-Agent": "LelipsClipper/0.1", "Accept": "application/json"})
    with urlopen(request, timeout=20) as response:
        data = json.load(response)
    keys = ("title", "creator", "license", "license_url", "foreign_landing_url", "url", "attribution")
    return [{key: row.get(key) for key in keys} for row in data.get("results", [])]


def earshot_match(file, description):
    return run(["earshot", "match", Path(file).resolve(strict=True), description], timeout=180)


def real_sfx_mix(skill_dir, video, cue_file, output):
    import sys
    root = Path(skill_dir).resolve()
    output = Path(output).resolve()
    if output.exists():
        raise ValueError(f"Would overwrite {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    import tempfile
    with tempfile.TemporaryDirectory(prefix="lelips-real-sfx-") as work:
        resolved = Path(work) / "cues.json"
        run([sys.executable, root / "scripts/from_cues.py", Path(cue_file).resolve(strict=True),
             "--video", Path(video).resolve(strict=True), "--out", resolved], cwd=root)
        run([sys.executable, root / "scripts/mix.py", resolved, "--out", output, "--voice-safe"], cwd=root)
    return str(output)


