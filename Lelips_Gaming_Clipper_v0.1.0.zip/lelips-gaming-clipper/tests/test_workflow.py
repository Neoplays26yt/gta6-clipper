"""Offline integration tests. Tests use generated, fully redistributable fixtures."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase

from lelips.audio import catalog
from lelips.common import FFMPEG, run, save
from lelips.detect import scan
from lelips.editor import render
from lelips.live import extract, parse_chat, segments, twitch
from lelips.source import review_sheet


class ChatTest(TestCase):
    def test_multiple_channels_and_spam(self):
        self.assertEqual(twitch("https://www.twitch.tv/KaiCenat"),"kaicenat")
        self.assertEqual(twitch("another_channel"),"another_channel")
        with self.assertRaises(ValueError):
            twitch("https://www.twitch.tv.evil.example/kaicenat")
        line = "@user-id=42;tmi-sent-ts=90000 :test!test@test PRIVMSG #kaicenat :no way"
        self.assertEqual(parse_chat(line),("kaicenat",90,"42","no way"))
        events = [(t,"normal","hello") for t in range(0,190,5)]
        events += [(61,"spammer","clip it")]*100
        events += [(91,str(i),"NO WAY") for i in range(9)]
        events += [(151,str(i),"raid!") for i in range(10)]
        candidates = scan(events)
        self.assertEqual(len(candidates),1)
        self.assertEqual(candidates[0]["unique_chatters"],10)
        self.assertLess(candidates[0]["start"],91)

    def test_real_segment_extract_and_detect_gap(self):
        with TemporaryDirectory() as temp:
            root = Path(temp)
            run(FFMPEG+["-f","lavfi","-i","testsrc2=s=320x180:r=30:d=9",
                        "-f","lavfi","-i","sine=f=440:d=9","-c:v","libx264","-g","60",
                        "-c:a","aac","-f","segment","-segment_time","2","-segment_list",
                        "segments.csv","-segment_list_type","csv","part-%08d.ts"],cwd=root)
            rows = segments(root)
            self.assertGreater(len(rows),3)
            result = extract(rows,2.4,7.1,root/"window.mp4")
            self.assertTrue(result["full_decode"])
            self.assertAlmostEqual(result["duration"],4.7,delta=.15)
            with self.assertRaisesRegex(ValueError,"gap"):
                extract(rows[:1]+rows[2:],rows[0][1]+0.25,rows[-1][2]-0.1,root/"gap.mp4")


class EditTest(TestCase):
    def test_portrait_publish_gate_and_render(self):
        with TemporaryDirectory() as temp:
            root = Path(temp)
            source = root/"source.mp4"
            run(FFMPEG+["-f","lavfi","-i","testsrc2=s=640x360:r=60:d=7",
                        "-f","lavfi","-i","sine=f=415:d=7","-c:v","libx264","-threads","2",
                        "-pix_fmt","yuv420p","-c:a","aac",source])
            bed = root/"bed.wav"
            run(FFMPEG+["-f","lavfi","-i","sine=f=100:d=2",bed])
            art = root/"insert.png"
            run(FFMPEG+["-f","lavfi","-i","color=c=0x35465e:s=400x300:d=1","-frames:v","1",
                        "-threads","1",art])
            path = root/"job.json"
            save(path,{"version":1,"source":source.name,"title":"Fixture","credit":"Generated in test",
                       "shots":[{"start":0,"end":1.2,"layout":"context"},
                                {"start":1.6,"end":2.9,"layout":"stack","face":[.03,.03,.36,.46],
                                 "game":[0,0,1,1],"transition":"film-burn","pitch":-3},
                                {"start":3.1,"end":3.8,"layout":"fill","transition":"flash",
                                 "insert":art.name,"insert_credit":"Generated in test"},
                                {"start":5,"end":6.1,"layout":"fill","focus":.65,"zoom":1.2,"pitch":3,"push":0.07}],
                       "pitch_mixed_audio":True,
                       "words":[{"start":0.3,"end":0.5,"text":"One"},
                                {"start":0.5,"end":0.88,"text":"moment","emphasis":True}],
                       "labels":[{"text":"REPLAY","start":3.25,"end":4.2}],
                       "cues":[{"at":2.1,"id":"impact","why":"Fixture impact"}],
                       "music":{"path":bed.name,"credit":"Generated tone","gain_db":-28}})
            with self.assertRaisesRegex(ValueError,"Unverified sound rights"):
                render(path,root/"denied.mp4",preview=True)
            checked = render(path,root/"done.mp4",private_sfx=True)
            self.assertEqual((checked["width"],checked["height"]),(1080,1920))
            self.assertAlmostEqual(checked["duration"],4.3,delta=.05)
            self.assertEqual([cue["id"] for cue in checked["used_sfx"]],["whoosh","impact","flash"])
            self.assertEqual(checked["captions"],2)
            self.assertLess(float(checked["mix_measurements"]["true_peak_dbtp"]),0)
            self.assertEqual(len(catalog(check=True)),10)
            result = review_sheet(root/"done.mp4",root/"sheet.jpg",0,None)
            self.assertTrue(Path(result["image"]).is_file())


class WatchTest(TestCase):
    def test_two_channel_watch_processes(self):
        import os
        from unittest.mock import patch
        from lelips.live import watch

        with TemporaryDirectory() as temp:
            root = Path(temp)
            fixture = root/"input.ts"
            run(FFMPEG+["-f","lavfi","-i","testsrc2=s=160x90:r=30:d=4",
                        "-f","lavfi","-i","sine=f=410:d=4","-g","15","-threads","1",
                        "-c:v","libx264","-c:a","aac","-f","mpegts",fixture])
            bin_dir = root/"bin"
            bin_dir.mkdir()
            recorder = bin_dir/"streamlink"
            recorder.write_text(
                "#!/usr/bin/env python3\n"
                "import os,sys,time,pathlib\n"
                "data = pathlib.Path(os.environ['LELIPS_TEST_STREAM']).read_bytes()\n"
                "for part in range(4):\n"
                "    sys.stdout.buffer.write(data); sys.stdout.buffer.flush(); time.sleep(0.5)\n",
                encoding="utf-8")
            recorder.chmod(0o755)
            config = root/"channels.json"
            save(config,{"channels":["alpha","beta"]})
            with patch.dict(os.environ,{"PATH":str(bin_dir)+os.pathsep+os.environ["PATH"],
                                        "LELIPS_TEST_STREAM":str(fixture)}):
                result = watch(config,root/"session",0.10,manual=True)
            self.assertEqual({row["channel"] for row in result},{"alpha","beta"})
            for channel in ("alpha","beta"):
                folder = root/"session"/channel
                self.assertTrue((folder/"captures"/"run-0001"/"segments.csv").exists())
                self.assertFalse(list(folder.glob("captures/*/part-*.ts")))
