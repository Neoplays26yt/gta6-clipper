# Lelips edit direction

Start on an understandable decision, unusual visual, or line that changes the scene. Keep one setup and one payoff. Let the audience see what caused the reaction. A genuine reaction at the end is often stronger than a closing card.

- Keep HUD or gameplay context when it explains the joke. Check vertical crops around sudden camera motion, facecam layout changes, and action at screen edges. A face visible on screen is not proof it is the current speaker. A fixed source crop is deliberate when a moving tracker would follow the wrong person.
- Reframe per shot. Use an eased push during a reaction hold. A freeze-like beat can come from a deliberate held image with the source audio underneath. Use a cleared reaction image for a meme cutaway only when it adds to the joke. Ordinary cuts do most of the work.
- Before adding a transition, check whether the punchline lands better on a direct cut or a short pause. A flash can get back from a cutaway. A low whoosh into a new angle should follow a meaningful scene change.
- Inspect Whisper’s words and timings. Keep speaker colors stable. Emphasize a relevant word or phrase, avoid word confetti, and check the left/right and bottom mobile overlay regions. Use existing creator audio by default. No announcer, explanation board, progress bar, channel intro or end card by default.
- Review a private preview before making the final render. Check source quotes in context, start/end boundaries, reaction timing, crops, caption collisions, speaker levels and music. If another viewer is available and authorized, give them the preview without telling them the intended verdict. Fix evidence-backed problems.

For a batch, shortlist candidates separately for each creator, then select the best across the batch. Rank by independent setup, on-screen payoff, clean source and distinctive reaction. De-duplicate the same scene from the same stream. Do not label a stream GTA VI unless footage or metadata establishes that.
