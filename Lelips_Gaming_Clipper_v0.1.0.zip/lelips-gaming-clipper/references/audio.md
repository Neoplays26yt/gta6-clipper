# Sound design

The included Drive folder is 10 SFX 4. The bundled files are decoded 48 kHz WAV copies matched to the ten original Drive file IDs. Each file's checksum and origin are in assets/drive-sfx/manifest.json. Their usage and redistribution licence was not established. Keep the package private. Verify terms or use a cleared catalog for public posting. Check the original source for attribution.

| ID | Use when it improves the beat |
| --- | --- |
| bass | A heavy reveal after the audience understands what changed. |
| impact | A single contact/punchline transient, preferably behind or just after dialogue. |
| radio | A tiny communication/UI beat where the actual game sound does not already cover it. |
| snap | An abrupt editorial reframe or reveal. |
| suspense | Build into a short payoff, never as filler under random speech. |
| slowdown | A brief shift into a reaction hold, with space before the next line. |
| flash | A short return from a cutaway, paired with the flash only when it helps. |
| charge | A tracked build when the action is already building. |
| whoosh | A move or transition with clear visual direction. |
| gear | Escalation into action or a change of pace. |

Audition before picking. Avoid adding a second impact if the game already supplies one. Keep words intelligible and check that music doesn't double a song already in the source. Align audible transients with action, not just the beginning of the media file. A cue’s offset trims leading padding and its mix time snaps to the nearest output frame. Allow silence to carry a reaction.

```bash
lelips sfx
lelips openverse "short dry camera shutter"
lelips import-sfx ./cleared-effects work/catalog --source 'https://original-provider.example' --license 'CC0'
lelips earshot-match work/sound.wav "a short dry mechanical shutter"
lelips real-sfx /path/to/Clipwing/skills/real-sfx work/rough.mp4 work/native-cues.json work/external-mix.mp4
```

Openverse discovers sounds and reports source links. Confirm the creator and licence at the original page, obtain the file there, and import it. Earshot is optional and must already be callable on PATH. Real SFX is optional and uses its own installed version, indexed asset libraries, and native cue schema. Use that companion's setup check before invoking the adapter. It takes a clean preview so the same cue won't be mixed twice. The built-in mixer uses Lelips cue JSON and works without any of those external tools.

Upstream: [Openverse](https://docs.openverse.org/api/reference/search_algorithm.html), [Earshot](https://github.com/Leonxlnx/earshot), [Real SFX](https://github.com/Clipwing/skills/tree/main/skills/real-sfx).
