# Twitch capture

**Quick test** uses a channel name or full HTTPS Twitch channel URL. It needs Streamlink on PATH and a live source. An already ended stream needs an available VOD URL or a source file.

```bash
lelips capture-test https://www.twitch.tv/kaicenat work/kai-test.ts --seconds 30
lelips verify work/kai-test.ts
```

**Watch multiple channels** in a bounded cloud run. Copy examples/channels.json to your job directory. Add up to five channel logins and raise max_channels as needed. Start with two or three. Select creators and streams whose footage you are allowed to use. Configure `TWITCH_CHAT_LOGIN` and `TWITCH_CHAT_TOKEN` on the host using a Twitch user access token with `chat:read`. Supply secrets through the host's secret environment. The Twitch username for that token may differ from any monitored channel. A bot with write permissions is unnecessary.

```bash
lelips watch work/channels.json work/launch-capture --minutes 45
# From a second terminal during the run, if you see an event:
lelips mark work/launch-capture kaicenat
```

Per-channel status and candidate files are under the session directory. Each channel gets its own bounded FFmpeg rolling buffer, retry backoff, timestamps and candidate limit. There is one read-only TLS chat connection. Twitch authentication and channel availability can vary. Run watch with `--manual` to capture and accept marks without connecting to chat. The capture-test and upload paths are also available without chat credentials.

Signals: five-second bins, per-channel rolling median, unique chatter counts, hype words, and raid suppression. Manual markers use the host’s current time by default. Candidate starts and ends depend on the last finalized segment and include up to 20 seconds of lead-in plus roughly 10 seconds after the estimated event. Output files are candidates for review.

The listener estimates where chat falls on the recorded timeline. Playback delivery, keyframes, viewer reaction and ads can shift the estimate. Adjust playback_delay_seconds and reaction_seconds after a real sample. The extractor rejects holes it observes between known capture segments and never joins separate recording attempts. The capture starts when connected and covers what Streamlink receives during that interval.

**VOD path** takes an authorized local file or accessible Twitch VOD. For replay chat, point scan-vod to a TwitchDownloader export or a flat JSON array `[{"at":12.3,"author":"viewer-id","text":"no way"}]`. If replay chat is unavailable, use manual windows, scenes and transcript evidence. Chat windows are ranked locally and keep aggregate counts in the result.

```bash
lelips fetch-vod 'https://www.twitch.tv/videos/123456789' work/source.mp4
lelips scan-vod work/source.mp4 work/chat.json
lelips sheet work/source.mp4 work/review.jpg --start 120 --end 150
```

A capture session must remain running. Chat sessions, transient notebooks and short-lived jobs have lifetimes independent of this skill. Use a persistent server for unattended capture. Temporary video segments are discarded after a capture attempt. Save candidate MP4s outside the disposable runtime before it ends.

Sources: [Streamlink Twitch documentation](https://streamlink.github.io/cli/plugins/twitch.html), [Streamlink CLI](https://streamlink.github.io/cli.html), [Twitch IRC authentication](https://dev.twitch.tv/docs/chat/irc/), [TwitchDownloader CLI](https://github.com/lay295/TwitchDownloader/tree/master/TwitchDownloaderCLI).
