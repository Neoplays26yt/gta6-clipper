# Edit plan and render commands

Use UTF-8 JSON with `version: 1`. All paths are local, relative to the plan's directory or absolute. Times are seconds. Source shot times use the original file’s clock. Words, graphic labels, and sound effects use the edited output clock starting at zero. A rough cut is the easiest way to get the correct caption clock.

```json
{
  "version": 1,
  "source": "candidate.mp4",
  "title": "The getaway lasted four seconds",
  "credit": "@streamer · https://www.twitch.tv/streamer",
  "shots": [
    {"start": 1.2, "end": 4.6, "layout": "context"},
    {"start": 4.6, "end": 9.2, "layout": "stack", "face": [0.73, 0.03, 0.24, 0.28],
     "game": [0, 0, 1, 1], "transition": "film-burn", "push": 0.04}
  ],
  "words": "words.json",
  "cues": [
    {"id": "impact", "at": 6.1, "gain_db": -18, "length": 0.5, "why": "Car lands and the streamer reacts"}
  ]
}
```

| Key | Behavior |
| --- | --- |
| shots | Chronological source ranges. End exclusive. Quantized to 30 fps. Maximum 30 seconds across all shots. |
| layout | context uses the full picture with a blurred backdrop. fill uses a focal horizontal crop. stack gives facecam the upper 30% and gameplay the remaining space. Use context if filling would hide essential HUD or action. |
| face, game | Normalized source rectangles as [left, top, width, height]. Required face for stack. Game defaults to the full source frame. |
| focus, zoom, push | Horizontal focal position 0–1, static zoom 1–1.5 for context/fill, eased in-shot push 0–0.2 (adds up to 20% magnification). |
| transition | cut, flash or film-burn. First shot must start on a cut. Film-burn is a warm light flash at the incoming cut, with no duration overlap. |
| insert, insert_credit | An optional PNG/JPG/WebP reaction cutaway replaces the shot picture while its original audio continues. Use owned or cleared art and record its credit. |
| pitch | Optional semitone adjustment −6 to +6 at constant tempo. Requires rubberband and explicit top-level `pitch_mixed_audio: true`. It affects the mixed source sound for the selected shot. Use a short range and audition for artifacts. |
| words | Either the path to a JSON object with a `words` field, or an inline array. Item: `{"start":0.2,"end":0.55,"text":"Wait","speaker":1,"emphasis":false}`. The renderer uses short grouped phrases with timed highlights. Speaker IDs 0–3 are chosen by the editor. |
| labels | Up to four short top-safe graphic callouts. Item: `{"text":"ONE LAST TRY","start":0.4,"end":1.8}`. Leave them off if the source is clear without them. |
| cues | Item fields: id, at, why, optional gain_db (-40 to -6), offset (trim front), length (max five seconds). Maximum ten including automatic transition cues. |
| sound_catalog | Alternative local directory with manifest.json and assets. Verify licensing on the source page. Automatic transition IDs can be disabled with `transition_sounds: false` when switching catalogs. |
| music | Optional `{"path":"bed.wav","credit":"Title / creator / licence / URL","gain_db":-27}`. The soundtrack is ducked against the source audio. |
| credit | Creator and permanent source link when available. For live candidates also retain original channel and source capture time in job notes. |

Commands, after making a plan without a `words` file initially:

```bash
lelips render work/edit.json work/rough.mp4 --preview --rough
lelips transcribe work/rough.mp4 work/words.json
# Add "words": "words.json" to the plan and correct transcript errors.
lelips render work/edit.json work/preview.mp4 --preview --private-sfx
lelips render work/edit.json work/final.mp4 --private-sfx
lelips verify work/final.mp4
```

Use `--private-sfx` for the included Drive pack. For a cleared catalog omit that flag. Existing outputs are protected from overwrites. Each render also saves an adjacent .report.json with measured duration, full decode, loudness, cues and credits. The values describe the decoded mix and do not certify perceived sound quality or lip sync.
