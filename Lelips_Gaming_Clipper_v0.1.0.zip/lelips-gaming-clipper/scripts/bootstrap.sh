#!/usr/bin/env bash
set -euo pipefail
repo="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
profile="${1:-capture}"
case "$profile" in
  render|capture|cpu|gpu) ;;
  *) printf 'Usage: %s [render|capture|cpu|gpu]\n' "$0" >&2; exit 2 ;;
esac
command -v uv >/dev/null || { printf 'Install uv in this cloud environment first.\n' >&2; exit 1; }
command -v ffmpeg >/dev/null && command -v ffprobe >/dev/null ||
  { printf 'The cloud environment needs ffmpeg and ffprobe on PATH.\n' >&2; exit 1; }
cd "$repo"
export UV_PROJECT_ENVIRONMENT="${UV_PROJECT_ENVIRONMENT:-$repo/.venv}"
if [[ "$profile" == render ]]; then
  uv sync --locked
else
  uv sync --locked --extra capture --inexact
fi
case "$profile" in
  cpu) uv pip install --python "$UV_PROJECT_ENVIRONMENT/bin/python" --torch-backend cpu 'openai-whisper==20250625' ;;
  gpu) uv pip install --python "$UV_PROJECT_ENVIRONMENT/bin/python" --torch-backend auto 'openai-whisper==20250625' ;;
esac
export PATH="$UV_PROJECT_ENVIRONMENT/bin:$PATH"
lelips doctor
if [[ "$profile" == gpu ]]; then
  "$UV_PROJECT_ENVIRONMENT/bin/python" -c 'import torch; assert torch.cuda.is_available(), "PyTorch cannot use CUDA in this session"'
fi
